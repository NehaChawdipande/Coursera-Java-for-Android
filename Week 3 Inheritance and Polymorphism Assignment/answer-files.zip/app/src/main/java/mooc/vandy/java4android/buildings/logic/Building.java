package mooc.vandy.java4android.buildings.logic;

/**
 * This is the Building class file.
 */
public class Building {
    private int mLength;
    private int mWidth;
    private int mLotLength;
    private int mLotWidth;

    public Building(int mLength, int mWidth, int mLotLength, int mLotWidth)
    {
     this.mLength = mLength;
     this.mWidth = mWidth;
     this.mLotLength = mLotLength;
     this.mLotWidth = mLotWidth;
    }

     //getters

    public int getLength() {
        return mLength;
    }

    public int getLotLength() {
        return mLotLength;
    }

    public int getWidth() {
        return mWidth;
    }

    public int getLotWidth() {
        return mLotWidth;
    }

    //setters

    public void setLength(int mLength) {
        this.mLength = mLength;
    }

    public void setLotLength(int mLotLength) {
        this.mLotLength = mLotLength;
    }

    public void setWidth(int mWidth) {
        this.mWidth = mWidth;
    }
    public void setLotWidth(int mLotWidth) {
        this.mLotWidth = mLotWidth;
    }

    //calculations
    public int calcBuildingArea() {
        return mLength * mWidth;
    }


    public int calcLotArea() {
        return  mLotLength * mLotWidth;
    }

    public String toString() {
        return "Owner:n/a";
    }

}
