package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    public int calculate(int arg1, int arg2){
        return  arg1-arg2;
    }
}
